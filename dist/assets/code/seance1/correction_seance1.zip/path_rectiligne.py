# exo
import turtle as trt

for i in range(10):
    trt.forward(100)
    trt.left(90)
    trt.forward(10)
    trt.left(90)
    trt.forward(100)
    trt.right(90)
    trt.forward(10)
    trt.right(90)

trt.done()
