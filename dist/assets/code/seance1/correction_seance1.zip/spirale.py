# exo
import turtle as trt

for x in range(20):
    trt.forward(12 * x)
    trt.left(90)

trt.done()
