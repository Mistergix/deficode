import turtle as trt

def faireGateau():
	trt.color("yellow")
	trt.right(90)
	trt.forward(20)
	trt.color('black')
	trt.forward(45)
	trt.color('pink')
	trt.left(90)
	trt.forward(50)
	trt.right(90)
	trt.forward(50)
	trt.right(90)
	trt.forward(100)
	trt.right(90)
	trt.forward(50)
	trt.right(90)
	trt.forward(50)

faireGateau()


trt.done()
